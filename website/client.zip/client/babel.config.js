/* eslint-disable import/no-commonjs */
module.exports = {
  presets: [
    '@vue/cli-plugin-babel/preset',
  ],
};
