<template functional>
  <div>{{ props.notification }}</div>
</template>
