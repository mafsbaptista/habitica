<template>
  <!-- Container component used when you only need an empty view to support children routes-->
  <router-view />
</template>
