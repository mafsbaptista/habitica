<template>
  <div
    class="modal-footer"
  >
    <!-- TODO disabled for now, see https://github.com/HabitRPG/habitica/issues/11283 -->
  </div>
</template>

<style lang="scss" scoped>
.modal-footer {
  border-top: none;
}
</style>

<script>
</script>
