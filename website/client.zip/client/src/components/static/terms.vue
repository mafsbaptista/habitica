<template>
  <!-- eslint-disable max-len -->
  <div class="container-fluid">
    <h1>Terms of Use</h1>
    <p class="pagemeta">
      Last updated July 27, 2015
      <br>
      <small>(Corrected minimum age requirement to under 13 years of age per COPPA)</small>
      <br>
      <br>
    </p>
    <p>
      HabitRPG &lpar;or 'we'&rpar; provides services through our
      software applications for various devices and platforms &lpar;'HabitRPG
      Applications'&rpar; and the HabitRPG&period;com domain&comma; and any sub domains thereto
      &lpar;the 'Sites'&rpar;&period; Individually or collectively&comma; HabitRPG Applications and
      Sites may be referred to as the 'Services'&period;
    </p>
    <p>
      Please read the following terms and conditions &lpar;'Terms of
      Service'&rpar; carefully&period; These Terms of Service govern your access to and
      use of the Services and HabitRPG Content &lpar;defined below&rpar; and set forth
      the legally binding terms for your use of the Services and HabitRPG
      Content&comma; whether or not you have registered as a Member&period;
    </p>
    <p>
      Certain areas of the Services &lpar;and your access to or use of
      HabitRPG Content&rpar; may have different terms and conditions posted or may
      require you to agree with and accept additional terms and conditions&period; If
      there is a conflict between these Terms of Service and terms and
      conditions posted for a specific area of the Services or HabitRPG
      Content&comma; the latter terms and conditions will take precedence with
      respect to your use of or access to that area of the Services or HabitRPG
      Content&period;
    </p>
    <p>
      YOU ACKNOWLEDGE AND AGREE THAT&comma; BY CLICKING ON THE 'I AGREE' OR
      'I ACCEPT' BUTTON&comma; OR BY ACCESSING OR USING THE SERVICES OR BY
      DOWNLOADING OR POSTING ANY CONTENT FROM OR ON THE SITES OR THROUGH THE
      SERVICES&comma; YOU ARE INDICATING THAT YOU HAVE READ&comma; UNDERSTAND AND AGREE TO
      BE BOUND BY THESE TERMS&comma; WHETHER OR NOT YOU HAVE REGISTERED AS A MEMBER&comma;
      AND AGREE TO OUR PRIVACY POLICY AS DESCRIBED BELOW&period; IF YOU DO NOT AGREE
      TO THESE TERMS&comma; THEN YOU HAVE NO RIGHT TO ACCESS OR USE THE SERVICES OR
      HABITRPG CONTENT&period;
    </p>
    <p>
      <strong>Modification</strong>
      <br>HabitRPG reserves the right&comma; at its sole discretion&comma; to modify&comma;
      discontinue or terminate the Services&comma; including any portion thereof on
      a global or individual basis&comma; or to modify these Terms of Service&comma; at
      any time and without prior notice&period; If we modify these Terms of Service&comma;
      we will update the 'Last Updated Date' above and post the modification
      on the Sites and perhaps elsewhere within the Services&period; By continuing to
      access or use the Services after we have posted a modification to these
      Terms of Service or have provided you with notice of a modification&comma; you
      are indicating that you agree to be bound by the modified Terms of
      Service&period; If the modified Terms of Service are not acceptable to you&comma;
      your only recourse is to cease using the Services&period;
    </p>
    <p>
      <strong>Eligibility and HabitRPG Account Registration</strong>
      <br>In order to access certain features of the Sites and Services&comma; and to
      post any Public User Content &lpar;defined below&rpar; on the Sites or through the
      Services&comma; you must register to create an account &lpar;'HabitRPG Account'&rpar; and
      become a 'Member'&period; In compliance with privacy laws&comma; we do not allow
      people below the age of 13 to create accounts&semi; please see our Privacy
      Policy for further information&period; During the registration process&comma; you
      will be required to provide certain information and you will establish a
      username and a password&period; You agree to provide accurate&comma; current and
      complete information during the registration process and to update such
      information to keep it accurate&comma; current and complete&period; HabitRPG reserves
      the right to suspend or terminate your HabitRPG Account if any
      information provided during the registration process or thereafter
      proves to be inaccurate&comma; not current or incomplete&period; If you are not a
      Member you may browse all areas of the Sites or use the parts of the
      Services that are not limited to Members only&period; You are responsible for
      safeguarding your password&period; You agree not to disclose your password to
      any third party and to take sole responsibility for any activities or
      actions under your HabitRPG Account&comma; whether or not you have authorized
      such activities or actions&period; You agree to immediately notify HabitRPG of
      any unauthorized use of your HabitRPG Account&period; We are not liable for any
      damages or losses caused by someone using your account without your
      permission&period;
    </p>
    <p>
      <strong>Privacy</strong>
      <br>See
      <a href="/static/privacy">HabitRPG&apos;s Privacy Policy</a> for
      information and notices concerning HabitRPG&apos;s collection and use of your
      personal information&period; If you have any questions about the HabitRPG
      Privacy Policy&comma; please contact HabitRPG at privacy AT HabitRPG&period;com&period; By
      accessing the Services you are agreeing to the terms of our Privacy
      Policy&period;
    </p>
    <p>
      <strong>Content</strong>
      <br>Certain types of content are made available through the Services&period;
      'HabitRPG Content' means&comma; collectively&comma; the text&comma; data&comma; graphics&comma; images&comma;
      illustrations&comma; forms and look and feel attributes&comma; HabitRPG trademarks
      and logos and other content made available through the Services&comma;
      including any technology or code making up the Services&comma; excluding User
      Content&period; 'Public User Content' means the text&comma; data&comma; graphics&comma; images&comma; photos&comma;
      video or audiovisual content&comma; hypertext links and any other content uploaded&comma;
      transmitted or submitted by a Member via the Services with the intent to share
      with other users&period; 'Private User Content' means data created through the services
      exclusively for personal use or private sharing&period;
      This includes tasks and related data created in HabitRPG Tasks that have not
      been explicitly shared publicly&period;
      You understand that by using any of the Services&comma; you may encounter content
      that may be deemed offensive&comma; indecent&comma; or objectionable&comma; which content
      may or may not be identified as having explicit language&comma; and that the
      results of any search or entering of a particular URL may automatically
      and unintentionally generate links or references to objectionable
      material&period; Nevertheless&comma; you agree to use the Services at your sole risk
      and that we shall not have any liability to you for content that may be
      found to be offensive&comma; indecent&comma; or objectionable&period;
    </p>
    <p>
      <strong>Ownership</strong>
      <br>The Services and HabitRPG Content are protected by copyright&comma; trademark&comma;
      and other laws of the United States and foreign countries&period; Except as
      expressly provided in these Terms of Service&comma; HabitRPG and its licensors
      exclusively own all right&comma; title and interest in and to the Services and
      HabitRPG Content&comma; including all associated intellectual property rights&period;
      You will not remove&comma; alter or obscure any copyright&comma; trademark&comma; service
      mark or other proprietary rights notices incorporated in or accompanying
      the Services or HabitRPG Content&period;
    </p>
    <p>
      <strong>HabitRPG License</strong>
      <br>Subject to your compliance with the terms and conditions of these Terms
      of Service&comma; HabitRPG grants you a limited&comma; non-exclusive&comma;
      non-transferable license&comma; without the right to sublicense&comma; to access&comma;
      use&comma; view&comma; download and print&comma; where applicable&comma; the Services and any
      HabitRPG Content solely for your personal and non-commercial purposes&period;
      You will not use&comma; copy&comma; adapt&comma; modify&comma; prepare derivative works based
      upon&comma; distribute&comma; license&comma; sell&comma; transfer&comma; publicly display&comma; publicly
      perform&comma; transmit&comma; stream&comma; broadcast or otherwise exploit the Services
      or HabitRPG Content&comma; except as expressly permitted in these Terms of
      Service&period; No licenses or rights are granted to you by implication or
      otherwise under any intellectual property rights owned or controlled by
      HabitRPG or its licensors&comma; except for the licenses and rights expressly
      granted in these Terms of Service&period; With respect to HabitRPG Applications&comma;
      your license is limited to use of such applications on platforms and
      devices that you own or control&comma; and you may not distribute or make the
      HabitRPG Applications available over a network where it could be used by
      multiple devices at the same time&period;
    </p>
    <p>
      <strong>Public User Content</strong>
      <br>By making available any Public User Content through the Services&comma; you hereby
      grant to HabitRPG a worldwide&comma; irrevocable&comma; perpetual&comma; non-exclusive&comma;
      transferable&comma; royalty-free license&comma; with the right to sublicense&comma; to
      use&comma; copy&comma; adapt&comma; modify&comma; distribute&comma; license&comma; sell&comma; transfer&comma; publicly
      display&comma; publicly perform&comma; transmit&comma; stream&comma; broadcast and otherwise
      exploit such Public User Content only on&comma; through or by means of the Services&period;
      HabitRPG does not claim any ownership rights in any such Public User Content and
      nothing in these Terms of Service will be deemed to restrict any rights
      that you may have to use and exploit any such Public User Content&period;
    </p>
    <p>
      You acknowledge and agree that you are solely responsible for all
      Public User Content that you make available through the Services&period; Accordingly&comma;
      you represent and warrant that&colon; &lpar;i&rpar; you either are the sole and
      exclusive owner of all Public User Content that you make available through the
      Services or you have all rights&comma; licenses&comma; consents and releases that
      are necessary to grant to HabitRPG the rights in such Public User Content&comma; as
      contemplated under these Terms of Service&semi; and &lpar;ii&rpar; neither the User
      Content nor your posting&comma; uploading&comma; publication&comma; submission or
      transmittal of the Public User Content or HabitRPG&apos;s use of the Public User Content &lpar;or
      any portion thereof&rpar; on&comma; through or by means of the Services will
      infringe&comma; misappropriate or violate a third party&apos;s patent&comma; copyright&comma;
      trademark&comma; trade secret&comma; moral rights or other intellectual property
      rights&comma; or rights of publicity or privacy&comma; or result in the violation of
      any applicable law or regulation&period;
    </p>
    <p>
      Copyrighted Materials&colon; No Infringing Use&period; You will not use the
      Services to offer&comma; display&comma; distribute&comma; transmit&comma; route&comma; provide
      connections to or store any material that infringes copyrighted works or
      otherwise violates or promotes the violation of the intellectual
      property rights of any third party&period; HabitRPG has adopted and implemented
      a policy that provides for the termination in appropriate circumstances
      of the accounts of users who repeatedly infringe or are believed to be
      or are charged with repeatedly infringing the rights of copyright
      holders&period;
    </p>
    <p>
      <strong>Notify Us of Infringers</strong>
      <br>If you believe that something on the Services violates your copyright&comma;
      notify our copyright agent in writing&period; The contact information for our
      copyright agent is at the bottom of this section&period;
    </p>
    <p>
      In order for us to take action&comma; you must do the following in your
      notice&colon;
    </p>
    <p>
      &lpar;1&rpar; provide your physical or electronic signature&semi; &lpar;2&rpar; identify
      the copyrighted work that you believe is being infringed&semi; &lpar;3&rpar; identify
      the item on the Services that you think is infringing your work and
      include sufficient information about where the material is located on
      the Services &lpar;including which website and URL&rpar; so that we can find it&semi;
      &lpar;4&rpar; provide us with a way to contact you&comma; such as your address&comma;
      telephone number&comma; or e-mail&semi; &lpar;5&rpar; provide a statement that you believe in
      good faith that the item you have identified as infringing is not
      authorized by the copyright owner&comma; its agent&comma; or the law to be used on
      the Services&semi; and &lpar;6&rpar; provide a statement that the information you
      provide in your notice is accurate&comma; and that &lpar;under penalty of perjury&rpar;&comma;
      you are authorized to act on behalf of the copyright owner whose work is
      being infringed&period;
    </p>
    <p>Here is the contact information for our copyright agent&colon;</p>
    <p>
      Copyright Enforcement
      <br>HabitRPG, Inc.
      <br>11870 Santa Monica Blvd., Suite 106-577
      <br>Los Angeles, CA 90025
      <br>E-Mail&colon;
      <a href="mailto:admin@habitica.com">admin@habitica.com</a>
    </p>
    <p>
      Again&comma; we cannot take action unless you give us all the required
      information&period;
    </p>
    <p>
      <strong>Ratings and Comments & Feedback&period;</strong>
      <br>You can rate and make comments about content made available through the
      Services &lpar;'Comments'&rpar;&period; HabitRPG advises you to exercise caution and good
      judgment when leaving such Comments&period; Once you complete and submit your
      Comments to the Services you will not be able to go back and edit your
      Comments&period; You should also be aware that you could be held legally
      responsible for damages to someone&apos;s reputation if your Comments are
      deemed to be defamatory&period; Without limiting any other terms of this Terms
      of Service&comma; HabitRPG may&comma; but is under no obligation to&comma; monitor or
      censor Comments and disclaims any and all liability relating thereto&period;
      Notwithstanding the foregoing&comma; HabitRPG does reserve the right&comma; in its
      sole discretion&comma; to remove any Comments that it deems to be improper&comma;
      inappropriate or inconsistent with the online activities that are
      permitted under these Terms of Service&period; We welcome and encourage you to
      provide feedback&comma; comments and suggestions for improvements to the
      Services &lpar;'Feedback'&rpar;&period; You may submit Feedback by emailing us at support
      AT HabitRPG&period;com&period; You acknowledge and agree that all Comments and Feedback
      will be the sole and exclusive property of HabitRPG and you hereby
      irrevocably assign to HabitRPG and agree to irrevocably assign to HabitRPG
      all of your right&comma; title&comma; and interest in and to all Comments and
      Feedback&comma; including without limitation all worldwide patent rights&comma;
      copyright rights&comma; trade secret rights&comma; and other proprietary or
      intellectual property rights therein&period; At HabitRPG&apos;s request and expense&comma;
      you will execute documents and take such further acts as HabitRPG may
      reasonably request to assist HabitRPG to acquire&comma; perfect&comma; and maintain
      its intellectual property rights and other legal protections for the
      Comments and Feedback&period;
    </p>
    <p>
      <strong>Interactions between Users</strong>
      <br>You are solely responsible for your interactions &lpar;including any
      disputes&rpar; with other users&period; You understand that HabitRPG does not in any
      way screen HabitRPG users&comma; except to only allow people aged 13 and over
      to create accounts&period; You are solely responsible for&comma; and will exercise
      caution&comma; discretion&comma; common sense and judgment in&comma; using the Services
      and disclosing personal information to other HabitRPG users&period; You agree to
      take reasonable precautions in all interactions with other HabitRPG
      users&comma; particularly if you decide to meet a HabitRPG user offline&comma; or in
      person&period; Your use of the Services&comma; HabitRPG Content and any other content
      made available through the Services is at your sole risk and discretion
      and HabitRPG hereby disclaims any and all liability to you or any third
      party relating thereto&period; HabitRPG reserves the right to contact Members&comma;
      in compliance with applicable law&comma; in order to evaluate compliance with
      the rules and policies in these Terms of Service&period; You will cooperate
      fully with HabitRPG to investigate any suspected unlawful&comma; fraudulent or
      improper activity&comma; including&comma; without limitation&comma; granting authorized
      HabitRPG representatives access to any password-protected portions of
      your HabitRPG Account&period;
    </p>
    <p>
      <strong>General Prohibitions</strong>
      <br>You agree not to do any of the following while using the Services or
      HabitRPG Content&colon;
      <br>
    </p>
    <ul>
      <li>
        Post&comma; upload&comma; publish&comma; submit or transmit any text&comma; graphics&comma;
        images&comma; software&comma; music&comma; audio&comma; video&comma; information or other material
        that&colon; &lpar;i&rpar; infringes&comma; misappropriates or violates a third party&apos;s
        patent&comma; copyright&comma; trademark&comma; trade secret&comma; moral rights or other
        intellectual property rights&comma; or rights of publicity or privacy&semi; &lpar;ii&rpar;
        violates&comma; or encourages any conduct that would violate&comma; any applicable
        law or regulation or would give rise to civil liability&semi; &lpar;iii&rpar; is
        fraudulent&comma; false&comma; misleading or deceptive&semi; &lpar;iv&rpar; is defamatory&comma;
        obscene&comma; pornographic&comma; vulgar or offensive&semi; &lpar;v&rpar; promotes
        discrimination&comma; bigotry&comma; racism&comma; hatred&comma; harassment or harm against any
        individual or group&semi; &lpar;vi&rpar; is violent or threatening or promotes
        violence or actions that are threatening to any other person&semi; or &lpar;vii&rpar;
        promotes illegal or harmful activities or substances &lpar;including but not
        limited to activities that promote or provide instructional information
        regarding the manufacture or purchase of illegal weapons or illegal
        substances&rpar;&period;
      </li>
      <li>
        Use&comma; display&comma; mirror&comma; frame or utilize framing techniques to
        enclose the Services&comma; or any individual element or materials within the
        Services&comma; HabitRPG&apos;s name&comma; any HabitRPG trademark&comma; logo or other
        proprietary information&comma; the content of any text or the layout and
        design of any page or form contained on a page&comma; without HabitRPG&apos;s
        express written consent&semi;
      </li>
      <li>
        Access&comma; tamper with&comma; or use non-public areas of the Services&comma;
        HabitRPG&apos;s computer systems&comma; or the technical delivery systems of
        HabitRPG&apos;s providers&semi;
      </li>
      <li>
        Attempt to probe&comma; scan&comma; or test the vulnerability of any
        HabitRPG system or network or breach any security or authentication
        measures&semi;
      </li>
      <li>
        Avoid&comma; bypass&comma; remove&comma; deactivate&comma; impair&comma; descramble or
        otherwise circumvent any technological measure implemented by HabitRPG
        or any of HabitRPG&apos;s providers or any other third party &lpar;including
        another user&rpar; to protect the Services or HabitRPG Content&semi;
      </li>
      <li>
        Attempt to access or search the Services or HabitRPG Content or
        download HabitRPG Content from the Services through the use of any
        engine&comma; software&comma; tool&comma; agent&comma; device or mechanism &lpar;including spiders&comma;
        robots&comma; crawlers&comma; data mining tools or the like&rpar; other than the
        software and&sol;or search agents provided by HabitRPG or other generally
        available third party web browsers &lpar;such as Google Chrome&comma; Microsoft
        Internet Explorer&comma; Mozilla Firefox&comma; Safari or Opera&rpar;&semi;
      </li>
      <li>
        Send any unsolicited or unauthorized advertising&comma; promotional
        materials&comma; email&comma; junk mail&comma; spam&comma; chain letters or other form of
        solicitation&semi;
      </li>
      <li>
        Use any meta tags or other hidden text or metadata utilizing a
        HabitRPG trademark&comma; logo URL or product name without HabitRPG&apos;s express
        written consent&semi;
      </li>
      <li>
        Use the Services or HabitRPG Content for any commercial purpose
        or the benefit of any third party or in any manner not permitted by
        these Terms of Service&semi;
      </li>
      <li>
        Forge any TCP&sol;IP packet header or any part of the header
        information in any email or newsgroup posting&comma; or in any way use the
        Services or HabitRPG Content to send altered&comma; deceptive or false
        source-identifying information&semi;
      </li>
      <li>
        Attempt to decipher&comma; decompile&comma; disassemble or reverse
        engineer any of the software used to provide the Services or HabitRPG
        Content&semi;
      </li>
      <li>
        Interfere with&comma; or attempt to interfere with&comma; the access of
        any user&comma; host or network&comma; including&comma; without limitation&comma; sending a
        virus&comma; overloading&comma; flooding&comma; spamming&comma; or mail-bombing the Services&semi;
      </li>
      <li>
        Collect or store any personally identifiable information from
        the Services from other users of the Services without their express
        permission&semi;
      </li>
      <li>
        Impersonate or misrepresent your affiliation with any person
        or entity&semi; Violate any applicable law or regulation&semi; or
      </li>
      <li>
        Encourage or enable any other individual to do any of the
        foregoing&period;
      </li>
    </ul>
    <p>
      HabitRPG will have the right to investigate and prosecute
      violations of any of the above&comma; including intellectual property rights
      infringement and Services security issues&comma; to the fullest extent of the
      law&period; HabitRPG may involve and cooperate with law enforcement authorities
      in prosecuting users who violate these Terms of Service&period; You acknowledge
      that HabitRPG has no obligation to monitor your access to or use of the
      Services or HabitRPG Content or to review or edit any Public User Content&comma; but
      has the right to do so for the purpose of operating the Services&comma; to
      ensure your compliance with these Terms of Service&comma; or to comply with
      applicable law or the order or requirement of a court&comma; administrative
      agency or other governmental body&period; HabitRPG reserves the right&comma; at any
      time and without prior notice&comma; to remove or disable access to any
      HabitRPG Content&comma; including&comma; any Public User Content&comma; that HabitRPG&comma; in its sole
      discretion&comma; considers to be in violation of these Terms of Service or
      otherwise harmful to the Services&period;
    </p>
    <p>
      <strong>Links</strong>
      <br>The Services may contain links to third-party websites or resources&period; You
      acknowledge and agree that HabitRPG is not responsible or liable for&colon; &lpar;i&rpar;
      the availability or accuracy of such websites or resources&semi; or &lpar;ii&rpar; the
      content&comma; products&comma; or services on or available from such websites or
      resources&period; Links to such websites or resources do not imply any
      endorsement by HabitRPG of such websites or resources or the content&comma;
      products&comma; or services available from such websites or resources&period; You
      acknowledge sole responsibility for and assume all risk arising from
      your use of any such websites or resources&period;
    </p>
    <p>
      <strong>Termination and HabitRPG Account&semi; Cancellation</strong>
      <br>Without limiting other remedies&comma; HabitRPG may at any time suspend or
      terminate your HabitRPG Account and refuse to provide access to the
      Services&period; In addition&comma; HabitRPG may notify authorities or take any
      actions it deems appropriate&comma; without notice to you&comma; if HabitRPG suspects
      or determines&comma; in its own discretion&comma; that you may have or there is a
      significant risk that you have &lpar;i&rpar; failed to comply with any provision
      of these Terms of Service or any policies or rules established by
      HabitRPG&semi; or &lpar;ii&rpar; engaged in actions relating to or in the course of
      using the Services that may be illegal or cause liability&comma; harm&comma;
      embarrassment&comma; harassment&comma; abuse or disruption for you&comma; HabitRPG Users&comma;
      HabitRPG or any other third parties or the Services&period;
    </p>
    <p>
      You may terminate your HabitRPG Account at any time and for any
      reason by sending email to support AT HabitRPG&period;com&period; Upon any termination
      by a Member&comma; the related account will no longer be accessible&period;
    </p>
    <p>
      After any termination&comma; you understand and acknowledge that we
      will have no further obligation to provide the Services and all licenses
      and other rights granted to you by these Terms of Service will
      immediately cease&period; HabitRPG will not be liable to you or any third party
      for termination of the Services or termination of your use of either&period;
      UPON ANY TERMINATION OR SUSPENSION&comma; ANY CONTENT&comma; MATERIALS OR
      INFORMATION &lpar;INCLUDING PUBLIC USER CONTENT&rpar; THAT YOU HAVE SUBMITTED ON THE
      SERVICES OR THAT WHICH IS RELATED TO YOUR ACCOUNT MAY NO LONGER BE
      ACCESSED BY YOU&period; Furthermore&comma; HabitRPG will have no obligation to
      maintain any information stored in our database related to your account
      or to forward any information to you or any third party&period;
    </p>
    <p>
      Any suspension&comma; termination or cancellation will not affect your
      obligations to HabitRPG under these Terms of Service &lpar;including&comma; without
      limitation&comma; proprietary rights and ownership&comma; indemnification and
      limitation of liability&rpar;&comma; which by their sense and context are intended
      to survive such suspension&comma; termination or cancellation&period;
    </p>
    <p>
      <strong>Disclaimers</strong>
      <br>THE SERVICES&comma; HABITRPG CONTENT AND PUBLIC USER CONTENT ARE PROVIDED 'AS IS'&comma;
      WITHOUT WARRANTY OF ANY KIND&comma; EITHER EXPRESS OR IMPLIED&period; WITHOUT
      LIMITING THE FOREGOING&comma; HABITRPG EXPLICITLY DISCLAIMS ANY WARRANTIES OF
      MERCHANTABILITY&comma; FITNESS FOR A PARTICULAR PURPOSE&comma; QUIET ENJOYMENT OR
      NON-INFRINGEMENT&comma; AND ANY WARRANTIES ARISING OUT OF COURSE OF DEALING OR
      USAGE OF TRADE&period;
    </p>
    <p>
      HABITRPG MAKES NO WARRANTY THAT THE SERVICES&comma; HABITRPG CONTENT OR
      PUBLIC USER CONTENT WILL MEET YOUR REQUIREMENTS OR BE AVAILABLE ON AN
      UNINTERRUPTED&comma; SECURE&comma; OR ERROR-FREE BASIS&period; HABITRPG MAKES NO WARRANTY
      REGARDING THE QUALITY OF ANY PRODUCTS&comma; SERVICES OR CONTENT PURCHASED OR
      OBTAINED THROUGH THE SERVICES OR THE ACCURACY&comma; TIMELINESS&comma; TRUTHFULNESS&comma;
      COMPLETENESS OR RELIABILITY OF ANY CONTENT OBTAINED THROUGH THE
      SERVICES&period;
    </p>
    <p>
      NO ADVICE OR INFORMATION&comma; WHETHER ORAL OR WRITTEN&comma; OBTAINED FROM
      HABITRPG OR THROUGH THE SERVICES&comma; HABITRPG CONTENT OR PUBLIC USER CONTENT&comma; WILL
      CREATE ANY WARRANTY NOT EXPRESSLY MADE HEREIN&period;
    </p>
    <p>
      <strong>Indemnity</strong>
      <br>You agree to defend&comma; indemnify&comma; and hold HabitRPG&comma; its officers&comma;
      directors&comma; employees and agents&comma; harmless from and against any claims&comma;
      liabilities&comma; damages&comma; losses&comma; and expenses&comma; including&comma; without
      limitation&comma; reasonable legal and accounting fees&comma; arising out of or in
      any way connected with Public User Content you submit to HabitRPG&comma; your access
      to or use of the Services or HabitRPG Content&comma; or your violation of these
      Terms of Service&period;
    </p>
    <p>
      <strong>Limitation of Liability</strong>
      <br>YOU ACKNOWLEDGE AND AGREE THAT&comma; TO THE MAXIMUM EXTENT PERMITTED BY LAW&comma;
      THE ENTIRE RISK ARISING OUT OF YOUR ACCESS TO AND USE OF THE SERVICES
      AND CONTENT THEREIN REMAINS WITH YOU&period; NEITHER HABITRPG NOR ANY OTHER
      PARTY INVOLVED IN CREATING&comma; PRODUCING&comma; OR DELIVERING THE SERVICES OR
      HABITRPG CONTENT WILL BE LIABLE FOR ANY INCIDENTAL&comma; SPECIAL&comma; EXEMPLARY OR
      CONSEQUENTIAL DAMAGES&comma; INCLUDING LOST PROFITS&comma; LOSS OF DATA OR LOSS OF
      GOODWILL&comma; SERVICE INTERRUPTION&comma; COMPUTER DAMAGE OR SYSTEM FAILURE OR THE
      COST OF SUBSTITUTE PRODUCTS OR SERVICES&comma; ARISING OUT OF OR IN CONNECTION
      WITH THESE TERMS OR FROM THE USE OF OR INABILITY TO USE THE SERVICES OR
      CONTENT THEREIN&comma; WHETHER BASED ON WARRANTY&comma; CONTRACT&comma; TORT &lpar;INCLUDING
      NEGLIGENCE&rpar;&comma; PRODUCT LIABILITY OR ANY OTHER LEGAL THEORY&comma; AND WHETHER OR
      NOT HABITRPG HAS BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGE&comma; EVEN IF
      A LIMITED REMEDY SET FORTH HEREIN IS FOUND TO HAVE FAILED OF ITS
      ESSENTIAL PURPOSE&period; YOU SPECIFICALLY ACKNOWLEDGE THAT HABITRPG IS NOT
      LIABLE FOR THE DEFAMATORY&comma; OFFENSIVE OR ILLEGAL CONDUCT OF OTHER USERS
      OR THIRD PARTIES AND THAT THE RISK OF INJURY FROM THE FOREGOING RESTS
      ENTIRELY WITH YOU&period; FURTHER&comma; HABITRPG WILL HAVE NO LIABILITY TO YOU OR TO
      ANY THIRD PARTY FOR ANY PUBLIC USER CONTENT OR THIRD-PARTY CONTENT UPLOADED
      ONTO OR DOWNLOADED FROM THE SITES OR THROUGH THE SERVICES&period;
    </p>
    <p>
      IN NO EVENT WILL HABITRPG&apos;S AGGREGATE LIABILITY ARISING OUT OF OR
      IN CONNECTION WITH THESE TERMS OF SERVICE OR FROM THE USE OF OR
      INABILITY TO USE THE SITE&comma; SERVICES OR CONTENT THEREIN EXCEED ONE
      HUNDRED U&period;S&period; DOLLARS &lpar;&dollar;100&rpar;&period; THE LIMITATIONS OF DAMAGES SET FORTH ABOVE
      ARE FUNDAMENTAL ELEMENTS OF THE BASIS OF THE BARGAIN BETWEEN HABITRPG AND
      YOU&period; SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF
      LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES&comma; SO THE ABOVE
      LIMITATION MAY NOT APPLY TO YOU&period;
    </p>
    <p>
      <strong>Proprietary Rights Notices</strong>
      <br>All trademarks&comma; service marks&comma; logos&comma; trade names and any other
      proprietary designations of HabitRPG used herein are trademarks or
      registered trademarks of HabitRPG&period; Any other trademarks&comma; service marks&comma;
      logos&comma; trade names and any other proprietary designations are the
      trademarks or registered trademarks of their respective parties&period;
    </p>
    <p>
      <strong>Controlling Law and Jurisdiction</strong>
      <br>These Terms of Service and any action related thereto will be governed
      by the laws of the State of California without regard to its conflict of
      laws provisions&period; The exclusive jurisdiction and venue of any action with
      respect to the subject matter of these Terms of Service will be the
      courts having jurisdiction over disputes arising in Santa Clara County&comma;
      California&comma; and each of the parties hereto waives any objection to
      jurisdiction and venue in such courts&period;
    </p>
    <p>
      YOU AGREE THAT IF YOU WANT TO SUE US&comma; YOU MUST FILE YOUR LAWSUIT
      WITHIN ONE YEAR AFTER THE EVENT THAT GAVE RISE TO YOUR LAWSUIT&period;
      OTHERWISE&comma; YOUR LAWSUIT WILL BE PERMANENTLY BARRED&period;
    </p>
    <p>
      <strong>Export Control</strong>
      <br>You may not use or otherwise export or re-export the Services except as
      authorized by United States law and the laws of the jurisdiction in
      which the Services were obtained&period; In particular&comma; but without limitation&comma;
      the Services may not be exported or re-exported &lpar;a&rpar; into any U&period;S&period;
      embargoed countries or &lpar;b&rpar; to anyone on the U&period;S&period; Treasury Department&apos;s
      list of Specially Designated Nationals or the U&period;S&period; Department of
      Commerce Denied Person&apos;s List or Entity List&period; By using the Services&comma; you
      represent and warrant that you are not located in any such country or on
      any such list&period; You also agree that you will not use these products for
      any purposes prohibited by United States law&comma; including&comma; without
      limitation&comma; the development&comma; design&comma; manufacture or production of
      nuclear&comma; missiles&comma; or chemical or biological weapons&period;
    </p>
    <p>
      <strong>Entire Agreement</strong>
      <br>These Terms of Service constitute the entire and exclusive understanding
      and agreement between HabitRPG and you regarding the Services and HabitRPG
      Content&comma; and these Terms of Service supersede and replace any and all
      prior oral or written understandings or agreements between HabitRPG and
      you regarding the Services and HabitRPG Content&period;
    </p>
    <p>
      <strong>Assignment</strong>
      <br>You may not assign or transfer these Terms of Service&comma; by operation of
      law or otherwise&comma; without HabitRPG&apos;s prior written consent&period; Any attempt
      by you to assign or transfer these Terms of Service&comma; without such
      consent&comma; will be null and of no effect&period; HabitRPG may freely assign these
      Terms of Service&period; Subject to the foregoing&comma; these Terms of Service will
      bind and inure to the benefit of the parties&comma; their successors and
      permitted assigns&period;
    </p>
    <p>
      <strong>Notices</strong>
      <br>You consent to the use of&colon; &lpar;i&rpar; electronic means to complete these Terms
      of Service and to deliver any notices or other communications permitted
      or required hereunder&semi; and &lpar;ii&rpar; electronic records to store information
      related to these Terms of Service or your use of the Services&period; Any
      notices or other communications permitted to required hereunder&comma;
      including those regarding modifications to these Terms of Service&comma; will
      be in writing and given&colon; &lpar;x&rpar; by HabitRPG via email &lpar;in each case to the
      address that you provide&rpar; or &lpar;y&rpar; by posting to the Sites or Services&period;
      For notices made by e-mail&comma; the date of receipt will be deemed the date
      on which such notice is transmitted&period;
    </p>
    <p>
      <strong>General</strong>
      <br>The failure of HabitRPG to enforce any right or provision of these Terms
      of Service will not constitute a waiver of future enforcement of that
      right or provision&period; The waiver of any such right or provision will be
      effective only if in writing and signed by a duly authorized
      representative of HabitRPG&period; Except as expressly set forth in these Terms
      of Service&comma; the exercise by either party of any of its remedies under
      these Terms of Service will be without prejudice to its other remedies
      under these Terms of Service or otherwise&period; If for any reason a court of
      competent jurisdiction finds any provision of these Terms of Service
      invalid or unenforceable&comma; that provision will be enforced to the maximum
      extent permissible and the other provisions of these Terms of Service
      will remain in full force and effect&period;
    </p>
    <p>
      <strong>Contacting Us</strong>
      <br>If you have any questions about these Terms of Service&comma; please contact
      us at
      <a href="mailto:admin@habitica.com">admin@habitica.com</a>
    </p>
  </div>
  <!-- eslint-enable max-len -->
</template>
