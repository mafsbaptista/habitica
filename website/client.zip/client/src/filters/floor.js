export default function floor (val, power = 100) {
  return Math.floor(val * power) / power;
}
