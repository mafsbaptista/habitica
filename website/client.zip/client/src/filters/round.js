export default function round (val) {
  return Math.round(val * 100) / 100;
}
