export default function floorWholeNumber (val) {
  return Math.floor(val);
}
