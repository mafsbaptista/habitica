export function market (store) {
  return store.state.shops.market;
}

export function quests (store) {
  return store.state.shops.market;
}
