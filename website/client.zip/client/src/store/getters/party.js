export function members (store) { // eslint-disable-line import/prefer-default-export
  return store.state.partyMembers.data;
}
