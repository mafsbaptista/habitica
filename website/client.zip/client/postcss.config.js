/* eslint-disable import/no-commonjs */
module.exports = {
  plugins: {
    autoprefixer: {},
  },
};
